#Exercise 1: Variables
v1="Joaquin"
print(v1)
v1="Jairo"
print(v1)
#Exercise 5: USB Shopper
USBsticks=50//6
price=USBsticks * 6
change=50 - price
print("She can buy",USBsticks, "USB sticks for",price, "pounds and will have",change, "pounds left")
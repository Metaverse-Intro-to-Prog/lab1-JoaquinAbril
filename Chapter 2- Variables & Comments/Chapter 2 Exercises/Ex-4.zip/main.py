#Exercise 4: Favorite Number
fn="7"
print("My favorite number is:",fn)
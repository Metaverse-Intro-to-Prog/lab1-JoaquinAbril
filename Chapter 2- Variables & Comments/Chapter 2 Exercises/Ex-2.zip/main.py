#Exercise 2: Variables
print("Kobe Bryant once said, \"After all, greatness is not for everybody.\" ")
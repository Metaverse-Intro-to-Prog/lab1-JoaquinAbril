#Exercise 3: Stripping Names
name="\tJoaquin\t"
print(name)
print("\n", name.lstrip())
print("\n", name.rstrip())
print("\n", name.strip())
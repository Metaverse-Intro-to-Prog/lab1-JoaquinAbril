#Exercise 2: Print the Version of Phyton
import sys
print("Phyton version")
print(sys.version)
print("Version info")
print(sys.version_info)
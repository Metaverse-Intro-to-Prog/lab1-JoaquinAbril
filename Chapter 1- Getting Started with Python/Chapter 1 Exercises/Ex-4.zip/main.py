#Exercise 4: Strings Concatination
v1="I"
v2="<3"
v3="U"
print(v1+v2+v3)
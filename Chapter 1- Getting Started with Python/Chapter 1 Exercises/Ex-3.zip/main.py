#Exercise 3: Print date and time
from datetime import datetime
print("The date and time is:")
print(datetime.now())

#Exercise 5: Compute are of Circle
from math import pi
r=float(input("Enter the radius of the circle:"))
print("Area",pi * r**2)